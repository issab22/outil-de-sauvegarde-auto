package partie1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class frame extends JFrame{
	
	JRadioButton rd1 = new JRadioButton("font 1");
	JRadioButton rd2 = new JRadioButton("font 2");
	
	JCheckBox chBlack = new JCheckBox("Rouge");
    JCheckBox chkBlue = new JCheckBox("Bleu");
    
    JTextArea ta = new JTextArea();
    
    String animals[] = {"Chien", "Chat", "Oiseau", "Vache"};
    String plantes[] = {"Orchids", "Cactus", "Cam�lia", "Cardon"};
    
    JComboBox jcb = new JComboBox(animals);
    
    JList jl = new JList(plantes);
    
    ButtonGroup bgroup1 = new ButtonGroup();
    ButtonGroup bgroup2 = new ButtonGroup();
    
    JPanel pnlPreview = new JPanel();
    JButton btnQuit = new JButton("Effacer");
	
    public frame() {
        super( "Apprend les composants" );
        
        JPanel contentPane = (JPanel) getContentPane();
        
        JPanel pnlLeft = new JPanel( new GridLayout( 3, 1 ) );
        pnlLeft.setPreferredSize( new Dimension( 100, 0 ) );
        ta.setPreferredSize(new Dimension(360, 340));
        ta.isMaximumSizeSet();
        
        ta.setLineWrap(true);
		ta.setWrapStyleWord(true);
        jl.setSelectionMode(DefaultListSelectionModel.SINGLE_SELECTION);
        pnlLeft.add( chBlack );
        chBlack.addItemListener( this::checkBox_itemStateChanged1 );
        
        pnlLeft.add( chkBlue );
        chkBlue.addItemListener( this::checkBox_itemStateChanged2 );
        
        bgroup2.add(chBlack);
        bgroup2.add(chkBlue);
        
        pnlLeft.add( rd1 );
        rd1.addItemListener( this::radioButtons_itemStateChanged1 );
        
        pnlLeft.add( rd2 );
        rd2.addItemListener( this::radioButtons_itemStateChanged2 );
        bgroup1.add(rd1);
        bgroup1.add(rd2);
        
        
        
        pnlLeft.add( jcb );

        jcb.addActionListener (new ActionListener () {
            public void actionPerformed(ActionEvent e) {
            	jcb_itemStateChanged(null);
            }
        });
        
        pnlLeft.add( jl );

        jl.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if (e.getValueIsAdjusting() == false) {
					jl_itemStateChanged(null);
				}
			}
		});
        
        contentPane.add( pnlLeft, BorderLayout.WEST );
        
        pnlPreview.add(ta);
        contentPane.add( pnlPreview, BorderLayout.CENTER );
        
        btnQuit.addActionListener( (e) -> ta.setText("") );
        contentPane.add( btnQuit, BorderLayout.SOUTH );

        this.setSize(500,340);
        this.setLocationRelativeTo( null );
    }
    
    void checkBox_itemStateChanged1(ItemEvent e) {
    	Color c = chBlack.isSelected() ?  Color.red  : Color.blue;
        this.ta.setForeground(c);
    }
    
    void checkBox_itemStateChanged2(ItemEvent e) {
    	Color c  = chkBlue.isSelected() ? Color.blue : Color.red;
        this.ta.setForeground(c);
    }

    void radioButtons_itemStateChanged1(ItemEvent e) {
    	Font font = rd1.isSelected() ? new Font("Agency FB", Font.BOLD, 20) : new Font("Segoe Script", Font.BOLD, 20);
    	this.ta.setFont(font);
    }
    
    void radioButtons_itemStateChanged2(ItemEvent e) {
    	Font font = rd2.isSelected() ? new Font("Segoe Script", Font.BOLD, 20) : new Font("Agency FB", Font.BOLD, 20);
    	this.ta.setFont(font);
    }
    
    void jcb_itemStateChanged(ItemEvent e) {
    	this.ta.setText(this.ta.getText() + " " + this.jcb.getSelectedItem());
    }
    
    void jl_itemStateChanged(ItemEvent e) {
    	this.ta.setText(this.ta.getText() + " " + this.jl.getSelectedValue());
    }
    
    public static void main(String[] args) throws Exception {
        frame frame = new frame();
        frame.setVisible( true );
    }

}
